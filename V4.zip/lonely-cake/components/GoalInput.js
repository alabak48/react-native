import React, {useState} from 'react';
import { Text, View, StyleSheet, TextInput, Button } from 'react-native';

const Goalnput = (props) => {

const [enteredGoal, setEnteredGoal] = useState("");

  const goalInpuHandler = enteredText => {
    setEnteredGoal(enteredText) 
  }

  return (
    <View>
      <TextInput placeholder="Enter list item" style={styles.listItem} 
      onChangeText={goalInpuHandler}
      value={enteredGoal}
      />
      <Button title="Add" onPress={props.onAddGoal.bind(this, enteredGoal)} />
     </View>
  )
};

const styles = StyleSheet.create({

})

export default Goalnput;